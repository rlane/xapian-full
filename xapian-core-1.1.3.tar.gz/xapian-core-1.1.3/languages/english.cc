/* This file was generated automatically by the Snowball to ISO C++ compiler */

#include <limits.h>
#include "english.h"

static const symbol s_pool[] = {
#define s_0_0 0
'a', 'r', 's', 'e', 'n',
#define s_0_1 5
'c', 'o', 'm', 'm', 'u', 'n',
#define s_0_2 11
'g', 'e', 'n', 'e', 'r',
#define s_1_0 (s_1_1 + 2)
#define s_1_1 16
'\'', 's', '\'',
#define s_1_2 s_1_1
#define s_2_0 19
'i', 'e', 'd',
#define s_2_1 (s_2_2 + 2)
#define s_2_2 22
'i', 'e', 's',
#define s_2_3 25
's', 's', 'e', 's',
#define s_2_4 s_2_3
#define s_2_5 29
'u', 's',
#define s_3_1 31
'b', 'b',
#define s_3_2 33
'd', 'd',
#define s_3_3 35
'f', 'f',
#define s_3_4 37
'g', 'g',
#define s_3_5 39
'b', 'l',
#define s_3_6 41
'm', 'm',
#define s_3_7 43
'n', 'n',
#define s_3_8 45
'p', 'p',
#define s_3_9 47
'r', 'r',
#define s_3_10 49
'a', 't',
#define s_3_11 51
't', 't',
#define s_3_12 53
'i', 'z',
#define s_4_0 (s_4_1 + 1)
#define s_4_1 s_4_4
#define s_4_2 s_4_5
#define s_4_3 (s_4_4 + 1)
#define s_4_4 55
'e', 'e', 'd', 'l', 'y',
#define s_4_5 60
'i', 'n', 'g', 'l', 'y',
#define s_5_0 65
'a', 'n', 'c', 'i',
#define s_5_1 69
'e', 'n', 'c', 'i',
#define s_5_2 73
'o', 'g', 'i',
#define s_5_3 (s_5_4 + 1)
#define s_5_4 (s_5_5 + 1)
#define s_5_5 76
'a', 'b', 'l', 'i',
#define s_5_6 80
'a', 'l', 'l', 'i',
#define s_5_7 84
'f', 'u', 'l', 'l', 'i',
#define s_5_8 89
'l', 'e', 's', 's', 'l', 'i',
#define s_5_9 95
'o', 'u', 's', 'l', 'i',
#define s_5_10 100
'e', 'n', 't', 'l', 'i',
#define s_5_11 105
'a', 'l', 'i', 't', 'i',
#define s_5_12 110
'b', 'i', 'l', 'i', 't', 'i',
#define s_5_13 116
'i', 'v', 'i', 't', 'i',
#define s_5_14 (s_5_15 + 1)
#define s_5_15 121
'a', 't', 'i', 'o', 'n', 'a', 'l',
#define s_5_16 128
'a', 'l', 'i', 's', 'm',
#define s_5_17 s_5_15
#define s_5_18 133
'i', 'z', 'a', 't', 'i', 'o', 'n',
#define s_5_19 140
'i', 'z', 'e', 'r',
#define s_5_20 144
'a', 't', 'o', 'r',
#define s_5_21 148
'i', 'v', 'e', 'n', 'e', 's', 's',
#define s_5_22 155
'f', 'u', 'l', 'n', 'e', 's', 's',
#define s_5_23 162
'o', 'u', 's', 'n', 'e', 's', 's',
#define s_6_0 169
'i', 'c', 'a', 't', 'e',
#define s_6_1 174
'a', 't', 'i', 'v', 'e',
#define s_6_2 179
'a', 'l', 'i', 'z', 'e',
#define s_6_3 184
'i', 'c', 'i', 't', 'i',
#define s_6_4 189
'i', 'c', 'a', 'l',
#define s_6_5 (s_6_6 + 1)
#define s_6_6 193
'a', 't', 'i', 'o', 'n', 'a', 'l',
#define s_6_7 200
'f', 'u', 'l',
#define s_6_8 203
'n', 'e', 's', 's',
#define s_7_0 207
'i', 'c',
#define s_7_1 209
'a', 'n', 'c', 'e',
#define s_7_2 213
'e', 'n', 'c', 'e',
#define s_7_3 217
'a', 'b', 'l', 'e',
#define s_7_4 221
'i', 'b', 'l', 'e',
#define s_7_5 225
'a', 't', 'e',
#define s_7_6 228
'i', 'v', 'e',
#define s_7_7 231
'i', 'z', 'e',
#define s_7_8 234
'i', 't', 'i',
#define s_7_9 237
'a', 'l',
#define s_7_10 239
'i', 's', 'm',
#define s_7_11 242
'i', 'o', 'n',
#define s_7_12 245
'e', 'r',
#define s_7_13 247
'o', 'u', 's',
#define s_7_14 250
'a', 'n', 't',
#define s_7_15 (s_7_16 + 1)
#define s_7_16 (s_7_17 + 1)
#define s_7_17 253
'e', 'm', 'e', 'n', 't',
#define s_8_0 258
'e',
#define s_8_1 259
'l',
#define s_9_0 260
's', 'u', 'c', 'c', 'e', 'e', 'd',
#define s_9_1 267
'p', 'r', 'o', 'c', 'e', 'e', 'd',
#define s_9_2 274
'e', 'x', 'c', 'e', 'e', 'd',
#define s_9_3 280
'c', 'a', 'n', 'n', 'i', 'n', 'g',
#define s_9_4 287
'i', 'n', 'n', 'i', 'n', 'g',
#define s_9_5 293
'e', 'a', 'r', 'r', 'i', 'n', 'g',
#define s_9_6 300
'h', 'e', 'r', 'r', 'i', 'n', 'g',
#define s_9_7 307
'o', 'u', 't', 'i', 'n', 'g',
#define s_10_0 313
'a', 'n', 'd', 'e', 's',
#define s_10_1 318
'a', 't', 'l', 'a', 's',
#define s_10_2 323
'b', 'i', 'a', 's',
#define s_10_3 327
'c', 'o', 's', 'm', 'o', 's',
#define s_10_4 333
'd', 'y', 'i', 'n', 'g',
#define s_10_5 338
'e', 'a', 'r', 'l', 'y',
#define s_10_6 343
'g', 'e', 'n', 't', 'l', 'y',
#define s_10_7 349
'h', 'o', 'w', 'e',
#define s_10_8 353
'i', 'd', 'l', 'y',
#define s_10_9 357
'l', 'y', 'i', 'n', 'g',
#define s_10_10 362
'n', 'e', 'w', 's',
#define s_10_11 366
'o', 'n', 'l', 'y',
#define s_10_12 370
's', 'i', 'n', 'g', 'l', 'y',
#define s_10_13 376
's', 'k', 'i', 'e', 's',
#define s_10_14 381
's', 'k', 'i', 's',
#define s_10_15 385
's', 'k', 'y',
#define s_10_16 388
't', 'y', 'i', 'n', 'g',
#define s_10_17 393
'u', 'g', 'l', 'y',
};


static const struct among a_0[3] =
{
/*  0 */ { 5, s_0_0, -1, -1},
/*  1 */ { 6, s_0_1, -1, -1},
/*  2 */ { 5, s_0_2, -1, -1}
};


static const struct among a_1[3] =
{
/*  0 */ { 1, s_1_0, -1, 1},
/*  1 */ { 3, s_1_1, 0, 1},
/*  2 */ { 2, s_1_2, -1, 1}
};


static const struct among a_2[6] =
{
/*  0 */ { 3, s_2_0, -1, 2},
/*  1 */ { 1, s_2_1, -1, 3},
/*  2 */ { 3, s_2_2, 1, 2},
/*  3 */ { 4, s_2_3, 1, 1},
/*  4 */ { 2, s_2_4, 1, -1},
/*  5 */ { 2, s_2_5, 1, -1}
};


static const struct among a_3[13] =
{
/*  0 */ { 0, 0, -1, 3},
/*  1 */ { 2, s_3_1, 0, 2},
/*  2 */ { 2, s_3_2, 0, 2},
/*  3 */ { 2, s_3_3, 0, 2},
/*  4 */ { 2, s_3_4, 0, 2},
/*  5 */ { 2, s_3_5, 0, 1},
/*  6 */ { 2, s_3_6, 0, 2},
/*  7 */ { 2, s_3_7, 0, 2},
/*  8 */ { 2, s_3_8, 0, 2},
/*  9 */ { 2, s_3_9, 0, 2},
/* 10 */ { 2, s_3_10, 0, 1},
/* 11 */ { 2, s_3_11, 0, 2},
/* 12 */ { 2, s_3_12, 0, 1}
};


static const struct among a_4[6] =
{
/*  0 */ { 2, s_4_0, -1, 2},
/*  1 */ { 3, s_4_1, 0, 1},
/*  2 */ { 3, s_4_2, -1, 2},
/*  3 */ { 4, s_4_3, -1, 2},
/*  4 */ { 5, s_4_4, 3, 1},
/*  5 */ { 5, s_4_5, -1, 2}
};


static const struct among a_5[24] =
{
/*  0 */ { 4, s_5_0, -1, 3},
/*  1 */ { 4, s_5_1, -1, 2},
/*  2 */ { 3, s_5_2, -1, 13},
/*  3 */ { 2, s_5_3, -1, 16},
/*  4 */ { 3, s_5_4, 3, 12},
/*  5 */ { 4, s_5_5, 4, 4},
/*  6 */ { 4, s_5_6, 3, 8},
/*  7 */ { 5, s_5_7, 3, 14},
/*  8 */ { 6, s_5_8, 3, 15},
/*  9 */ { 5, s_5_9, 3, 10},
/* 10 */ { 5, s_5_10, 3, 5},
/* 11 */ { 5, s_5_11, -1, 8},
/* 12 */ { 6, s_5_12, -1, 12},
/* 13 */ { 5, s_5_13, -1, 11},
/* 14 */ { 6, s_5_14, -1, 1},
/* 15 */ { 7, s_5_15, 14, 7},
/* 16 */ { 5, s_5_16, -1, 8},
/* 17 */ { 5, s_5_17, -1, 7},
/* 18 */ { 7, s_5_18, 17, 6},
/* 19 */ { 4, s_5_19, -1, 6},
/* 20 */ { 4, s_5_20, -1, 7},
/* 21 */ { 7, s_5_21, -1, 11},
/* 22 */ { 7, s_5_22, -1, 9},
/* 23 */ { 7, s_5_23, -1, 10}
};


static const struct among a_6[9] =
{
/*  0 */ { 5, s_6_0, -1, 4},
/*  1 */ { 5, s_6_1, -1, 6},
/*  2 */ { 5, s_6_2, -1, 3},
/*  3 */ { 5, s_6_3, -1, 4},
/*  4 */ { 4, s_6_4, -1, 4},
/*  5 */ { 6, s_6_5, -1, 1},
/*  6 */ { 7, s_6_6, 5, 2},
/*  7 */ { 3, s_6_7, -1, 5},
/*  8 */ { 4, s_6_8, -1, 5}
};


static const struct among a_7[18] =
{
/*  0 */ { 2, s_7_0, -1, 1},
/*  1 */ { 4, s_7_1, -1, 1},
/*  2 */ { 4, s_7_2, -1, 1},
/*  3 */ { 4, s_7_3, -1, 1},
/*  4 */ { 4, s_7_4, -1, 1},
/*  5 */ { 3, s_7_5, -1, 1},
/*  6 */ { 3, s_7_6, -1, 1},
/*  7 */ { 3, s_7_7, -1, 1},
/*  8 */ { 3, s_7_8, -1, 1},
/*  9 */ { 2, s_7_9, -1, 1},
/* 10 */ { 3, s_7_10, -1, 1},
/* 11 */ { 3, s_7_11, -1, 2},
/* 12 */ { 2, s_7_12, -1, 1},
/* 13 */ { 3, s_7_13, -1, 1},
/* 14 */ { 3, s_7_14, -1, 1},
/* 15 */ { 3, s_7_15, -1, 1},
/* 16 */ { 4, s_7_16, 15, 1},
/* 17 */ { 5, s_7_17, 16, 1}
};


static const struct among a_8[2] =
{
/*  0 */ { 1, s_8_0, -1, 1},
/*  1 */ { 1, s_8_1, -1, 2}
};


static const struct among a_9[8] =
{
/*  0 */ { 7, s_9_0, -1, -1},
/*  1 */ { 7, s_9_1, -1, -1},
/*  2 */ { 6, s_9_2, -1, -1},
/*  3 */ { 7, s_9_3, -1, -1},
/*  4 */ { 6, s_9_4, -1, -1},
/*  5 */ { 7, s_9_5, -1, -1},
/*  6 */ { 7, s_9_6, -1, -1},
/*  7 */ { 6, s_9_7, -1, -1}
};


static const struct among a_10[18] =
{
/*  0 */ { 5, s_10_0, -1, -1},
/*  1 */ { 5, s_10_1, -1, -1},
/*  2 */ { 4, s_10_2, -1, -1},
/*  3 */ { 6, s_10_3, -1, -1},
/*  4 */ { 5, s_10_4, -1, 3},
/*  5 */ { 5, s_10_5, -1, 9},
/*  6 */ { 6, s_10_6, -1, 7},
/*  7 */ { 4, s_10_7, -1, -1},
/*  8 */ { 4, s_10_8, -1, 6},
/*  9 */ { 5, s_10_9, -1, 4},
/* 10 */ { 4, s_10_10, -1, -1},
/* 11 */ { 4, s_10_11, -1, 10},
/* 12 */ { 6, s_10_12, -1, 11},
/* 13 */ { 5, s_10_13, -1, 2},
/* 14 */ { 4, s_10_14, -1, 1},
/* 15 */ { 3, s_10_15, -1, -1},
/* 16 */ { 5, s_10_16, -1, 5},
/* 17 */ { 4, s_10_17, -1, 8}
};

static const unsigned char g_v[] = { 17, 65, 16, 1 };

static const unsigned char g_v_WXY[] = { 1, 17, 65, 208, 1 };

static const unsigned char g_valid_LI[] = { 55, 141, 2 };

static const symbol s_0[] = { 'Y' };
static const symbol s_1[] = { 'Y' };
static const symbol s_2[] = { 's', 's' };
static const symbol s_3[] = { 'i' };
static const symbol s_4[] = { 'i', 'e' };
static const symbol s_5[] = { 'e', 'e' };
static const symbol s_6[] = { 'e' };
static const symbol s_7[] = { 'e' };
static const symbol s_8[] = { 'i' };
static const symbol s_9[] = { 't', 'i', 'o', 'n' };
static const symbol s_10[] = { 'e', 'n', 'c', 'e' };
static const symbol s_11[] = { 'a', 'n', 'c', 'e' };
static const symbol s_12[] = { 'a', 'b', 'l', 'e' };
static const symbol s_13[] = { 'e', 'n', 't' };
static const symbol s_14[] = { 'i', 'z', 'e' };
static const symbol s_15[] = { 'a', 't', 'e' };
static const symbol s_16[] = { 'a', 'l' };
static const symbol s_17[] = { 'f', 'u', 'l' };
static const symbol s_18[] = { 'o', 'u', 's' };
static const symbol s_19[] = { 'i', 'v', 'e' };
static const symbol s_20[] = { 'b', 'l', 'e' };
static const symbol s_21[] = { 'o', 'g' };
static const symbol s_22[] = { 'f', 'u', 'l' };
static const symbol s_23[] = { 'l', 'e', 's', 's' };
static const symbol s_24[] = { 't', 'i', 'o', 'n' };
static const symbol s_25[] = { 'a', 't', 'e' };
static const symbol s_26[] = { 'a', 'l' };
static const symbol s_27[] = { 'i', 'c' };
static const symbol s_28[] = { 's', 'k', 'i' };
static const symbol s_29[] = { 's', 'k', 'y' };
static const symbol s_30[] = { 'd', 'i', 'e' };
static const symbol s_31[] = { 'l', 'i', 'e' };
static const symbol s_32[] = { 't', 'i', 'e' };
static const symbol s_33[] = { 'i', 'd', 'l' };
static const symbol s_34[] = { 'g', 'e', 'n', 't', 'l' };
static const symbol s_35[] = { 'u', 'g', 'l', 'i' };
static const symbol s_36[] = { 'e', 'a', 'r', 'l', 'i' };
static const symbol s_37[] = { 'o', 'n', 'l', 'i' };
static const symbol s_38[] = { 's', 'i', 'n', 'g', 'l' };
static const symbol s_39[] = { 'y' };

int Xapian::InternalStemEnglish::r_prelude() { /* forwardmode */
    B_Y_found = 0; /* unset Y_found, line 26 */
    {   int c1 = c; /* do, line 27 */
        bra = c; /* [, line 27 */
        if (c == l || p[c] != 39) goto lab0;
        c++;
        ket = c; /* ], line 27 */
        if (slice_del() == -1) return -1; /* delete, line 27 */
    lab0:
        c = c1;
    }
    {   int c2 = c; /* do, line 28 */
        bra = c; /* [, line 28 */
        if (c == l || p[c] != 'y') goto lab1;
        c++;
        ket = c; /* ], line 28 */
        {   int ret = slice_from_s(1, s_0); /* <-, line 28 */
            if (ret < 0) return ret;
        }
        B_Y_found = 1; /* set Y_found, line 28 */
    lab1:
        c = c2;
    }
    {   int c3 = c; /* do, line 29 */
        while(1) { /* repeat, line 29 */
            int c4 = c;
            while(1) { /* goto, line 29 */
                int c5 = c;
                if (in_grouping_U(g_v, 97, 121, 0)) goto lab4; /* grouping v, line 29 */
                bra = c; /* [, line 29 */
                if (c == l || p[c] != 'y') goto lab4;
                c++;
                ket = c; /* ], line 29 */
                c = c5;
                break;
            lab4:
                c = c5;
                {   int ret = skip_utf8(p, c, 0, l, 1);
                    if (ret < 0) goto lab3;
                    c = ret; /* goto, line 29 */
                }
            }
            {   int ret = slice_from_s(1, s_1); /* <-, line 29 */
                if (ret < 0) return ret;
            }
            B_Y_found = 1; /* set Y_found, line 29 */
            continue;
        lab3:
            c = c4;
            break;
        }
        c = c3;
    }
    return 1;
}

int Xapian::InternalStemEnglish::r_mark_regions() { /* forwardmode */
    I_p1 = l; /* p1 = <integer expression>, line 33 */
    I_p2 = l; /* p2 = <integer expression>, line 34 */
    {   int c1 = c; /* do, line 35 */
        {   int c2 = c; /* or, line 41 */
            if (c + 4 >= l || p[c + 4] >> 5 != 3 || !((2375680 >> (p[c + 4] & 0x1f)) & 1)) goto lab2; /* among, line 36 */
            if (!(find_among(s_pool, a_0, 3, 0, 0))) goto lab2;
            goto lab1;
        lab2:
            c = c2;
            {   int ret = out_grouping_U(g_v, 97, 121, 1); /* gopast */ /* grouping v, line 41 */
                if (ret < 0) goto lab0;
                c += ret;
            }
            {   int ret = in_grouping_U(g_v, 97, 121, 1); /* gopast */ /* non v, line 41 */
                if (ret < 0) goto lab0;
                c += ret;
            }
        }
    lab1:
        I_p1 = c; /* setmark p1, line 42 */
        {   int ret = out_grouping_U(g_v, 97, 121, 1); /* gopast */ /* grouping v, line 43 */
            if (ret < 0) goto lab0;
            c += ret;
        }
        {   int ret = in_grouping_U(g_v, 97, 121, 1); /* gopast */ /* non v, line 43 */
            if (ret < 0) goto lab0;
            c += ret;
        }
        I_p2 = c; /* setmark p2, line 43 */
    lab0:
        c = c1;
    }
    return 1;
}

int Xapian::InternalStemEnglish::r_shortv() { /* backwardmode */
    {   int m1 = l - c; (void)m1; /* or, line 51 */
        if (out_grouping_b_U(g_v_WXY, 89, 121, 0)) goto lab1; /* non v_WXY, line 50 */
        if (in_grouping_b_U(g_v, 97, 121, 0)) goto lab1; /* grouping v, line 50 */
        if (out_grouping_b_U(g_v, 97, 121, 0)) goto lab1; /* non v, line 50 */
        goto lab0;
    lab1:
        c = l - m1;
        if (out_grouping_b_U(g_v, 97, 121, 0)) return 0; /* non v, line 52 */
        if (in_grouping_b_U(g_v, 97, 121, 0)) return 0; /* grouping v, line 52 */
        if (c > lb) return 0; /* atlimit, line 52 */
    }
lab0:
    return 1;
}

int Xapian::InternalStemEnglish::r_R1() { /* backwardmode */
    if (!(I_p1 <= c)) return 0; /* p1 <= <integer expression>, line 55 */
    return 1;
}

int Xapian::InternalStemEnglish::r_R2() { /* backwardmode */
    if (!(I_p2 <= c)) return 0; /* p2 <= <integer expression>, line 56 */
    return 1;
}

int Xapian::InternalStemEnglish::r_Step_1a() { /* backwardmode */
    int among_var;
    {   int m1 = l - c; (void)m1; /* try, line 59 */
        ket = c; /* [, line 60 */
        if (c <= lb || (p[c - 1] != 39 && p[c - 1] != 115)) { c = l - m1; goto lab0; } /* substring, line 60 */
        among_var = find_among_b(s_pool, a_1, 3, 0, 0);
        if (!(among_var)) { c = l - m1; goto lab0; }
        bra = c; /* ], line 60 */
        switch(among_var) { /* among, line 60 */
            case 0: { c = l - m1; goto lab0; }
            case 1:
                if (slice_del() == -1) return -1; /* delete, line 62 */
                break;
        }
    lab0:
        ;
    }
    ket = c; /* [, line 65 */
    if (c <= lb || (p[c - 1] != 100 && p[c - 1] != 115)) return 0; /* substring, line 65 */
    among_var = find_among_b(s_pool, a_2, 6, 0, 0);
    if (!(among_var)) return 0;
    bra = c; /* ], line 65 */
    switch(among_var) { /* among, line 65 */
        case 0: return 0;
        case 1:
            {   int ret = slice_from_s(2, s_2); /* <-, line 66 */
                if (ret < 0) return ret;
            }
            break;
        case 2:
            {   int m2 = l - c; (void)m2; /* or, line 68 */
                {   int ret = skip_utf8(p, c, lb, l, - 2); /* hop, line 68 */
                    if (ret < 0) goto lab2;
                    c = ret;
                }
                {   int ret = slice_from_s(1, s_3); /* <-, line 68 */
                    if (ret < 0) return ret;
                }
                goto lab1;
            lab2:
                c = l - m2;
                {   int ret = slice_from_s(2, s_4); /* <-, line 68 */
                    if (ret < 0) return ret;
                }
            }
        lab1:
            break;
        case 3:
            {   int ret = skip_utf8(p, c, lb, 0, -1);
                if (ret < 0) return 0;
                c = ret; /* next, line 69 */
            }
            {   int ret = out_grouping_b_U(g_v, 97, 121, 1); /* gopast */ /* grouping v, line 69 */
                if (ret < 0) return 0;
                c -= ret;
            }
            if (slice_del() == -1) return -1; /* delete, line 69 */
            break;
    }
    return 1;
}

int Xapian::InternalStemEnglish::r_Step_1b() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 75 */
    if (c - 1 <= lb || p[c - 1] >> 5 != 3 || !((33554576 >> (p[c - 1] & 0x1f)) & 1)) return 0; /* substring, line 75 */
    among_var = find_among_b(s_pool, a_4, 6, 0, 0);
    if (!(among_var)) return 0;
    bra = c; /* ], line 75 */
    switch(among_var) { /* among, line 75 */
        case 0: return 0;
        case 1:
            {   int ret = r_R1(); /* call R1, line 77 */
                if (ret <= 0) return ret;
            }
            {   int ret = slice_from_s(2, s_5); /* <-, line 77 */
                if (ret < 0) return ret;
            }
            break;
        case 2:
            {   int m_test1 = l - c; /* test, line 80 */
                {   int ret = out_grouping_b_U(g_v, 97, 121, 1); /* gopast */ /* grouping v, line 80 */
                    if (ret < 0) return 0;
                    c -= ret;
                }
                c = l - m_test1;
            }
            if (slice_del() == -1) return -1; /* delete, line 80 */
            {   int m_test2 = l - c; /* test, line 81 */
                if (c - 1 <= lb || p[c - 1] >> 5 != 3 || !((68514004 >> (p[c - 1] & 0x1f)) & 1)) among_var = 3; else /* substring, line 81 */
                among_var = find_among_b(s_pool, a_3, 13, 0, 0);
                if (!(among_var)) return 0;
                c = l - m_test2;
            }
            switch(among_var) { /* among, line 81 */
                case 0: return 0;
                case 1:
                    {   int saved_c = c;
                        insert_s(c, c, 1, s_6); /* <+, line 83 */
                        c = saved_c;
                    }
                    break;
                case 2:
                    ket = c; /* [, line 86 */
                    {   int ret = skip_utf8(p, c, lb, 0, -1);
                        if (ret < 0) return 0;
                        c = ret; /* next, line 86 */
                    }
                    bra = c; /* ], line 86 */
                    if (slice_del() == -1) return -1; /* delete, line 86 */
                    break;
                case 3:
                    if (c != I_p1) return 0; /* atmark, line 87 */
                    {   int m_test3 = l - c; /* test, line 87 */
                        {   int ret = r_shortv(); /* call shortv, line 87 */
                            if (ret <= 0) return ret;
                        }
                        c = l - m_test3;
                    }
                    {   int saved_c = c;
                        insert_s(c, c, 1, s_7); /* <+, line 87 */
                        c = saved_c;
                    }
                    break;
            }
            break;
    }
    return 1;
}

int Xapian::InternalStemEnglish::r_Step_1c() { /* backwardmode */
    ket = c; /* [, line 94 */
    {   int m1 = l - c; (void)m1; /* or, line 94 */
        if (c <= lb || p[c - 1] != 'y') goto lab1;
        c--;
        goto lab0;
    lab1:
        c = l - m1;
        if (c <= lb || p[c - 1] != 'Y') return 0;
        c--;
    }
lab0:
    bra = c; /* ], line 94 */
    if (out_grouping_b_U(g_v, 97, 121, 0)) return 0; /* non v, line 95 */
    {   int m2 = l - c; (void)m2; /* not, line 95 */
        if (c > lb) goto lab2; /* atlimit, line 95 */
        return 0;
    lab2:
        c = l - m2;
    }
    {   int ret = slice_from_s(1, s_8); /* <-, line 96 */
        if (ret < 0) return ret;
    }
    return 1;
}

int Xapian::InternalStemEnglish::r_Step_2() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 100 */
    if (c - 1 <= lb || p[c - 1] >> 5 != 3 || !((815616 >> (p[c - 1] & 0x1f)) & 1)) return 0; /* substring, line 100 */
    among_var = find_among_b(s_pool, a_5, 24, 0, 0);
    if (!(among_var)) return 0;
    bra = c; /* ], line 100 */
    {   int ret = r_R1(); /* call R1, line 100 */
        if (ret <= 0) return ret;
    }
    switch(among_var) { /* among, line 100 */
        case 0: return 0;
        case 1:
            {   int ret = slice_from_s(4, s_9); /* <-, line 101 */
                if (ret < 0) return ret;
            }
            break;
        case 2:
            {   int ret = slice_from_s(4, s_10); /* <-, line 102 */
                if (ret < 0) return ret;
            }
            break;
        case 3:
            {   int ret = slice_from_s(4, s_11); /* <-, line 103 */
                if (ret < 0) return ret;
            }
            break;
        case 4:
            {   int ret = slice_from_s(4, s_12); /* <-, line 104 */
                if (ret < 0) return ret;
            }
            break;
        case 5:
            {   int ret = slice_from_s(3, s_13); /* <-, line 105 */
                if (ret < 0) return ret;
            }
            break;
        case 6:
            {   int ret = slice_from_s(3, s_14); /* <-, line 107 */
                if (ret < 0) return ret;
            }
            break;
        case 7:
            {   int ret = slice_from_s(3, s_15); /* <-, line 109 */
                if (ret < 0) return ret;
            }
            break;
        case 8:
            {   int ret = slice_from_s(2, s_16); /* <-, line 111 */
                if (ret < 0) return ret;
            }
            break;
        case 9:
            {   int ret = slice_from_s(3, s_17); /* <-, line 112 */
                if (ret < 0) return ret;
            }
            break;
        case 10:
            {   int ret = slice_from_s(3, s_18); /* <-, line 114 */
                if (ret < 0) return ret;
            }
            break;
        case 11:
            {   int ret = slice_from_s(3, s_19); /* <-, line 116 */
                if (ret < 0) return ret;
            }
            break;
        case 12:
            {   int ret = slice_from_s(3, s_20); /* <-, line 118 */
                if (ret < 0) return ret;
            }
            break;
        case 13:
            if (c <= lb || p[c - 1] != 'l') return 0;
            c--;
            {   int ret = slice_from_s(2, s_21); /* <-, line 119 */
                if (ret < 0) return ret;
            }
            break;
        case 14:
            {   int ret = slice_from_s(3, s_22); /* <-, line 120 */
                if (ret < 0) return ret;
            }
            break;
        case 15:
            {   int ret = slice_from_s(4, s_23); /* <-, line 121 */
                if (ret < 0) return ret;
            }
            break;
        case 16:
            if (in_grouping_b_U(g_valid_LI, 99, 116, 0)) return 0; /* grouping valid_LI, line 122 */
            if (slice_del() == -1) return -1; /* delete, line 122 */
            break;
    }
    return 1;
}

int Xapian::InternalStemEnglish::r_Step_3() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 127 */
    if (c - 2 <= lb || p[c - 1] >> 5 != 3 || !((528928 >> (p[c - 1] & 0x1f)) & 1)) return 0; /* substring, line 127 */
    among_var = find_among_b(s_pool, a_6, 9, 0, 0);
    if (!(among_var)) return 0;
    bra = c; /* ], line 127 */
    {   int ret = r_R1(); /* call R1, line 127 */
        if (ret <= 0) return ret;
    }
    switch(among_var) { /* among, line 127 */
        case 0: return 0;
        case 1:
            {   int ret = slice_from_s(4, s_24); /* <-, line 128 */
                if (ret < 0) return ret;
            }
            break;
        case 2:
            {   int ret = slice_from_s(3, s_25); /* <-, line 129 */
                if (ret < 0) return ret;
            }
            break;
        case 3:
            {   int ret = slice_from_s(2, s_26); /* <-, line 130 */
                if (ret < 0) return ret;
            }
            break;
        case 4:
            {   int ret = slice_from_s(2, s_27); /* <-, line 132 */
                if (ret < 0) return ret;
            }
            break;
        case 5:
            if (slice_del() == -1) return -1; /* delete, line 134 */
            break;
        case 6:
            {   int ret = r_R2(); /* call R2, line 136 */
                if (ret <= 0) return ret;
            }
            if (slice_del() == -1) return -1; /* delete, line 136 */
            break;
    }
    return 1;
}

int Xapian::InternalStemEnglish::r_Step_4() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 141 */
    if (c - 1 <= lb || p[c - 1] >> 5 != 3 || !((1864232 >> (p[c - 1] & 0x1f)) & 1)) return 0; /* substring, line 141 */
    among_var = find_among_b(s_pool, a_7, 18, 0, 0);
    if (!(among_var)) return 0;
    bra = c; /* ], line 141 */
    {   int ret = r_R2(); /* call R2, line 141 */
        if (ret <= 0) return ret;
    }
    switch(among_var) { /* among, line 141 */
        case 0: return 0;
        case 1:
            if (slice_del() == -1) return -1; /* delete, line 144 */
            break;
        case 2:
            {   int m1 = l - c; (void)m1; /* or, line 145 */
                if (c <= lb || p[c - 1] != 's') goto lab1;
                c--;
                goto lab0;
            lab1:
                c = l - m1;
                if (c <= lb || p[c - 1] != 't') return 0;
                c--;
            }
        lab0:
            if (slice_del() == -1) return -1; /* delete, line 145 */
            break;
    }
    return 1;
}

int Xapian::InternalStemEnglish::r_Step_5() { /* backwardmode */
    int among_var;
    ket = c; /* [, line 150 */
    if (c <= lb || (p[c - 1] != 101 && p[c - 1] != 108)) return 0; /* substring, line 150 */
    among_var = find_among_b(s_pool, a_8, 2, 0, 0);
    if (!(among_var)) return 0;
    bra = c; /* ], line 150 */
    switch(among_var) { /* among, line 150 */
        case 0: return 0;
        case 1:
            {   int m1 = l - c; (void)m1; /* or, line 151 */
                {   int ret = r_R2(); /* call R2, line 151 */
                    if (ret == 0) goto lab1;
                    if (ret < 0) return ret;
                }
                goto lab0;
            lab1:
                c = l - m1;
                {   int ret = r_R1(); /* call R1, line 151 */
                    if (ret <= 0) return ret;
                }
                {   int m2 = l - c; (void)m2; /* not, line 151 */
                    {   int ret = r_shortv(); /* call shortv, line 151 */
                        if (ret == 0) goto lab2;
                        if (ret < 0) return ret;
                    }
                    return 0;
                lab2:
                    c = l - m2;
                }
            }
        lab0:
            if (slice_del() == -1) return -1; /* delete, line 151 */
            break;
        case 2:
            {   int ret = r_R2(); /* call R2, line 152 */
                if (ret <= 0) return ret;
            }
            if (c <= lb || p[c - 1] != 'l') return 0;
            c--;
            if (slice_del() == -1) return -1; /* delete, line 152 */
            break;
    }
    return 1;
}

int Xapian::InternalStemEnglish::r_exception2() { /* backwardmode */
    ket = c; /* [, line 158 */
    if (c - 5 <= lb || (p[c - 1] != 100 && p[c - 1] != 103)) return 0; /* substring, line 158 */
    if (!(find_among_b(s_pool, a_9, 8, 0, 0))) return 0;
    bra = c; /* ], line 158 */
    if (c > lb) return 0; /* atlimit, line 158 */
    return 1;
}

int Xapian::InternalStemEnglish::r_exception1() { /* forwardmode */
    int among_var;
    bra = c; /* [, line 170 */
    if (c + 2 >= l || p[c + 2] >> 5 != 3 || !((42750482 >> (p[c + 2] & 0x1f)) & 1)) return 0; /* substring, line 170 */
    among_var = find_among(s_pool, a_10, 18, 0, 0);
    if (!(among_var)) return 0;
    ket = c; /* ], line 170 */
    if (c < l) return 0; /* atlimit, line 170 */
    switch(among_var) { /* among, line 170 */
        case 0: return 0;
        case 1:
            {   int ret = slice_from_s(3, s_28); /* <-, line 174 */
                if (ret < 0) return ret;
            }
            break;
        case 2:
            {   int ret = slice_from_s(3, s_29); /* <-, line 175 */
                if (ret < 0) return ret;
            }
            break;
        case 3:
            {   int ret = slice_from_s(3, s_30); /* <-, line 176 */
                if (ret < 0) return ret;
            }
            break;
        case 4:
            {   int ret = slice_from_s(3, s_31); /* <-, line 177 */
                if (ret < 0) return ret;
            }
            break;
        case 5:
            {   int ret = slice_from_s(3, s_32); /* <-, line 178 */
                if (ret < 0) return ret;
            }
            break;
        case 6:
            {   int ret = slice_from_s(3, s_33); /* <-, line 182 */
                if (ret < 0) return ret;
            }
            break;
        case 7:
            {   int ret = slice_from_s(5, s_34); /* <-, line 183 */
                if (ret < 0) return ret;
            }
            break;
        case 8:
            {   int ret = slice_from_s(4, s_35); /* <-, line 184 */
                if (ret < 0) return ret;
            }
            break;
        case 9:
            {   int ret = slice_from_s(5, s_36); /* <-, line 185 */
                if (ret < 0) return ret;
            }
            break;
        case 10:
            {   int ret = slice_from_s(4, s_37); /* <-, line 186 */
                if (ret < 0) return ret;
            }
            break;
        case 11:
            {   int ret = slice_from_s(5, s_38); /* <-, line 187 */
                if (ret < 0) return ret;
            }
            break;
    }
    return 1;
}

int Xapian::InternalStemEnglish::r_postlude() { /* forwardmode */
    if (!(B_Y_found)) return 0; /* Boolean test Y_found, line 203 */
    while(1) { /* repeat, line 203 */
        int c1 = c;
        while(1) { /* goto, line 203 */
            int c2 = c;
            bra = c; /* [, line 203 */
            if (c == l || p[c] != 'Y') goto lab1;
            c++;
            ket = c; /* ], line 203 */
            c = c2;
            break;
        lab1:
            c = c2;
            {   int ret = skip_utf8(p, c, 0, l, 1);
                if (ret < 0) goto lab0;
                c = ret; /* goto, line 203 */
            }
        }
        {   int ret = slice_from_s(1, s_39); /* <-, line 203 */
            if (ret < 0) return ret;
        }
        continue;
    lab0:
        c = c1;
        break;
    }
    return 1;
}

int Xapian::InternalStemEnglish::stem() { /* forwardmode */
    {   int c1 = c; /* or, line 207 */
        {   int ret = r_exception1(); /* call exception1, line 207 */
            if (ret == 0) goto lab1;
            if (ret < 0) return ret;
        }
        goto lab0;
    lab1:
        c = c1;
        {   int c2 = c; /* not, line 208 */
            {   int ret = skip_utf8(p, c, 0, l, + 3); /* hop, line 208 */
                if (ret < 0) goto lab3;
                c = ret;
            }
            goto lab2;
        lab3:
            c = c2;
        }
        goto lab0;
    lab2:
        c = c1;
        {   int c3 = c; /* do, line 209 */
            {   int ret = r_prelude(); /* call prelude, line 209 */
                if (ret == 0) goto lab4;
                if (ret < 0) return ret;
            }
        lab4:
            c = c3;
        }
        {   int c4 = c; /* do, line 210 */
            {   int ret = r_mark_regions(); /* call mark_regions, line 210 */
                if (ret == 0) goto lab5;
                if (ret < 0) return ret;
            }
        lab5:
            c = c4;
        }
        lb = c; c = l; /* backwards, line 211 */

        {   int m5 = l - c; (void)m5; /* do, line 213 */
            {   int ret = r_Step_1a(); /* call Step_1a, line 213 */
                if (ret == 0) goto lab6;
                if (ret < 0) return ret;
            }
        lab6:
            c = l - m5;
        }
        {   int m6 = l - c; (void)m6; /* or, line 215 */
            {   int ret = r_exception2(); /* call exception2, line 215 */
                if (ret == 0) goto lab8;
                if (ret < 0) return ret;
            }
            goto lab7;
        lab8:
            c = l - m6;
            {   int m7 = l - c; (void)m7; /* do, line 217 */
                {   int ret = r_Step_1b(); /* call Step_1b, line 217 */
                    if (ret == 0) goto lab9;
                    if (ret < 0) return ret;
                }
            lab9:
                c = l - m7;
            }
            {   int m8 = l - c; (void)m8; /* do, line 218 */
                {   int ret = r_Step_1c(); /* call Step_1c, line 218 */
                    if (ret == 0) goto lab10;
                    if (ret < 0) return ret;
                }
            lab10:
                c = l - m8;
            }
            {   int m9 = l - c; (void)m9; /* do, line 220 */
                {   int ret = r_Step_2(); /* call Step_2, line 220 */
                    if (ret == 0) goto lab11;
                    if (ret < 0) return ret;
                }
            lab11:
                c = l - m9;
            }
            {   int m10 = l - c; (void)m10; /* do, line 221 */
                {   int ret = r_Step_3(); /* call Step_3, line 221 */
                    if (ret == 0) goto lab12;
                    if (ret < 0) return ret;
                }
            lab12:
                c = l - m10;
            }
            {   int m11 = l - c; (void)m11; /* do, line 222 */
                {   int ret = r_Step_4(); /* call Step_4, line 222 */
                    if (ret == 0) goto lab13;
                    if (ret < 0) return ret;
                }
            lab13:
                c = l - m11;
            }
            {   int m12 = l - c; (void)m12; /* do, line 224 */
                {   int ret = r_Step_5(); /* call Step_5, line 224 */
                    if (ret == 0) goto lab14;
                    if (ret < 0) return ret;
                }
            lab14:
                c = l - m12;
            }
        }
    lab7:
        c = lb;
        {   int c13 = c; /* do, line 227 */
            {   int ret = r_postlude(); /* call postlude, line 227 */
                if (ret == 0) goto lab15;
                if (ret < 0) return ret;
            }
        lab15:
            c = c13;
        }
    }
lab0:
    return 1;
}

Xapian::InternalStemEnglish::InternalStemEnglish()
    : B_Y_found(0), I_p2(0), I_p1(0)
{
}

Xapian::InternalStemEnglish::~InternalStemEnglish()
{
}

const char *
Xapian::InternalStemEnglish::get_description() const
{
    return "english";
}
