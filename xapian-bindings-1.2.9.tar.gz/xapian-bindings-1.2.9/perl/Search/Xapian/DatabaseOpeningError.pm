package Search::Xapian::DatabaseOpeningError;

=head1 NAME

Search::Xapian::DatabaseOpeningError -  DatabaseOpeningError indicates failure to open a database. 


=head1 DESCRIPTION


=cut
1;
