package Search::Xapian::RangeError;

=head1 NAME

Search::Xapian::RangeError -  RangeError indicates an attempt to access outside the bounds of a container.

=head1 DESCRIPTION


=cut
1;
