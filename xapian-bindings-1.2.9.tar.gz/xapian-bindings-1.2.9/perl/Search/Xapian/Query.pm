package Search::Xapian::Query;

1;
