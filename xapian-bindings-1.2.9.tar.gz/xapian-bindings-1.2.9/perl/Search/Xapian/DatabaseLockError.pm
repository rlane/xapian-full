package Search::Xapian::DatabaseLockError;

=head1 NAME

Search::Xapian::DatabaseLockError -  DatabaseLockError indicates failure to lock a database. 


=head1 DESCRIPTION


=cut
1;
