package Search::Xapian::DatabaseError;

=head1 NAME

Search::Xapian::DatabaseError -  DatabaseError indicates some sort of database related error. 


=head1 DESCRIPTION


=cut
1;
