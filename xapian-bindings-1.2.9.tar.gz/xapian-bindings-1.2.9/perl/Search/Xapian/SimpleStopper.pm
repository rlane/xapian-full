package Search::Xapian::SimpleStopper;

1;
