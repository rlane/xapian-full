package Search::Xapian::QueryParserError;

=head1 NAME

Search::Xapian::QueryParserError -  Indicates a query string can't be parsed. 


=head1 DESCRIPTION


=cut
1;
